-- phpMyAdmin SQL Dump
-- version 3.3.7deb5build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 14, 2011 at 01:11 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `Elgg`
--

-- --------------------------------------------------------

--
-- Table structure for table `elgg_access_collections`
--

DROP TABLE IF EXISTS `elgg_access_collections`;
CREATE TABLE IF NOT EXISTS `elgg_access_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `owner_guid` bigint(20) unsigned NOT NULL,
  `site_guid` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `owner_guid` (`owner_guid`),
  KEY `site_guid` (`site_guid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `elgg_access_collections`
--

INSERT INTO `elgg_access_collections` (`id`, `name`, `owner_guid`, `site_guid`) VALUES
(3, 'Group: Los de TPI', 51, 1);

-- --------------------------------------------------------

--
-- Table structure for table `elgg_access_collection_membership`
--

DROP TABLE IF EXISTS `elgg_access_collection_membership`;
CREATE TABLE IF NOT EXISTS `elgg_access_collection_membership` (
  `user_guid` int(11) NOT NULL,
  `access_collection_id` int(11) NOT NULL,
  PRIMARY KEY (`user_guid`,`access_collection_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `elgg_access_collection_membership`
--

INSERT INTO `elgg_access_collection_membership` (`user_guid`, `access_collection_id`) VALUES
(35, 3);

-- --------------------------------------------------------

--
-- Table structure for table `elgg_annotations`
--

DROP TABLE IF EXISTS `elgg_annotations`;
CREATE TABLE IF NOT EXISTS `elgg_annotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity_guid` bigint(20) unsigned NOT NULL,
  `name_id` int(11) NOT NULL,
  `value_id` int(11) NOT NULL,
  `value_type` enum('integer','text') NOT NULL,
  `owner_guid` bigint(20) unsigned NOT NULL,
  `access_id` int(11) NOT NULL,
  `time_created` int(11) NOT NULL,
  `enabled` enum('yes','no') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`),
  KEY `entity_guid` (`entity_guid`),
  KEY `name_id` (`name_id`),
  KEY `value_id` (`value_id`),
  KEY `owner_guid` (`owner_guid`),
  KEY `access_id` (`access_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `elgg_annotations`
--

INSERT INTO `elgg_annotations` (`id`, `entity_guid`, `name_id`, `value_id`, `value_type`, `owner_guid`, `access_id`, `time_created`, `enabled`) VALUES
(3, 40, 49, 14, 'text', 35, 0, 1323868027, 'yes'),
(4, 40, 49, 14, 'text', 35, 0, 1323868061, 'yes'),
(5, 45, 49, 52, 'text', 35, 0, 1323868075, 'yes'),
(6, 40, 49, 14, 'text', 35, 0, 1323868600, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `elgg_api_users`
--

DROP TABLE IF EXISTS `elgg_api_users`;
CREATE TABLE IF NOT EXISTS `elgg_api_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_guid` bigint(20) unsigned DEFAULT NULL,
  `api_key` varchar(40) DEFAULT NULL,
  `secret` varchar(40) NOT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_key` (`api_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `elgg_api_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `elgg_config`
--

DROP TABLE IF EXISTS `elgg_config`;
CREATE TABLE IF NOT EXISTS `elgg_config` (
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `site_guid` int(11) NOT NULL,
  PRIMARY KEY (`name`,`site_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `elgg_config`
--

INSERT INTO `elgg_config` (`name`, `value`, `site_guid`) VALUES
('view', 's:7:"default";', 1),
('language', 's:2:"en";', 1),
('default_access', 's:1:"2";', 1),
('allow_registration', 'b:1;', 1),
('walled_garden', 'b:0;', 1),
('allow_user_default_access', 's:0:"";', 1);

-- --------------------------------------------------------

--
-- Table structure for table `elgg_datalists`
--

DROP TABLE IF EXISTS `elgg_datalists`;
CREATE TABLE IF NOT EXISTS `elgg_datalists` (
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `elgg_datalists`
--

INSERT INTO `elgg_datalists` (`name`, `value`) VALUES
('filestore_run_once', '1323866716'),
('plugin_run_once', '1323866716'),
('elgg_widget_run_once', '1323866716'),
('installed', '1323866763'),
('path', '/var/www/'),
('dataroot', '/usr/local/elgg/data/'),
('default_site', '1'),
('version', '2011110700'),
('simplecache_enabled', '1'),
('viewpath_cache_enabled', '1'),
('processed_upgrades', 'a:34:{i:0;s:14:"2008100701.php";i:1;s:14:"2008101303.php";i:2;s:14:"2009022701.php";i:3;s:14:"2009041701.php";i:4;s:14:"2009070101.php";i:5;s:14:"2009102801.php";i:6;s:14:"2010010501.php";i:7;s:14:"2010033101.php";i:8;s:14:"2010040201.php";i:9;s:14:"2010052601.php";i:10;s:14:"2010060101.php";i:11;s:14:"2010060401.php";i:12;s:14:"2010061501.php";i:13;s:14:"2010062301.php";i:14;s:14:"2010062302.php";i:15;s:14:"2010070301.php";i:16;s:14:"2010071001.php";i:17;s:14:"2010071002.php";i:18;s:14:"2010111501.php";i:19;s:14:"2010121601.php";i:20;s:14:"2010121602.php";i:21;s:14:"2010121701.php";i:22;s:14:"2010123101.php";i:23;s:14:"2011010101.php";i:24;s:61:"2011021800-1.8_svn-goodbye_walled_garden-083121a656d06894.php";i:25;s:61:"2011022000-1.8_svn-custom_profile_fields-390ac967b0bb5665.php";i:26;s:60:"2011030700-1.8_svn-blog_status_metadata-4645225d7b440876.php";i:27;s:51:"2011031300-1.8_svn-twitter_api-12b832a5a7a3e1bd.php";i:28;s:57:"2011031600-1.8_svn-datalist_grows_up-0b8aec5a55cc1e1c.php";i:29;s:61:"2011032000-1.8_svn-widgets_arent_plugins-61836261fa280a5c.php";i:30;s:59:"2011032200-1.8_svn-admins_like_widgets-7f19d2783c1680d3.php";i:31;s:14:"2011052801.php";i:32;s:60:"2011061200-1.8b1-sites_need_a_site_guid-6d9dcbf46c0826cc.php";i:33;s:62:"2011092500-1.8.0.1-forum_reply_river_view-5758ce8d86ac56ce.php";}'),
('admin_registered', '1'),
('simplecache_lastupdate_default', '1323876908'),
('simplecache_lastcached_default', '1323876908'),
('__site_secret__', '443c25bbb153b86dffe365d78d6c7b22'),
('simplecache_lastupdate_failsafe', '1323876908'),
('simplecache_lastcached_failsafe', '1323876908'),
('simplecache_lastupdate_foaf', '1323876908'),
('simplecache_lastcached_foaf', '1323876908'),
('simplecache_lastupdate_ical', '1323876908'),
('simplecache_lastcached_ical', '1323876908'),
('simplecache_lastupdate_installation', '1323876908'),
('simplecache_lastcached_installation', '1323876908'),
('simplecache_lastupdate_json', '1323876908'),
('simplecache_lastcached_json', '1323876908'),
('simplecache_lastupdate_opendd', '1323876908'),
('simplecache_lastcached_opendd', '1323876908'),
('simplecache_lastupdate_php', '1323876908'),
('simplecache_lastcached_php', '1323876908'),
('simplecache_lastupdate_rss', '1323876908'),
('simplecache_lastcached_rss', '1323876908'),
('simplecache_lastupdate_xml', '1323876908'),
('simplecache_lastcached_xml', '1323876908');

-- --------------------------------------------------------

--
-- Table structure for table `elgg_entities`
--

DROP TABLE IF EXISTS `elgg_entities`;
CREATE TABLE IF NOT EXISTS `elgg_entities` (
  `guid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('object','user','group','site') NOT NULL,
  `subtype` int(11) DEFAULT NULL,
  `owner_guid` bigint(20) unsigned NOT NULL,
  `site_guid` bigint(20) unsigned NOT NULL,
  `container_guid` bigint(20) unsigned NOT NULL,
  `access_id` int(11) NOT NULL,
  `time_created` int(11) NOT NULL,
  `time_updated` int(11) NOT NULL,
  `last_action` int(11) NOT NULL DEFAULT '0',
  `enabled` enum('yes','no') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`guid`),
  KEY `type` (`type`),
  KEY `subtype` (`subtype`),
  KEY `owner_guid` (`owner_guid`),
  KEY `site_guid` (`site_guid`),
  KEY `container_guid` (`container_guid`),
  KEY `access_id` (`access_id`),
  KEY `time_created` (`time_created`),
  KEY `time_updated` (`time_updated`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `elgg_entities`
--

INSERT INTO `elgg_entities` (`guid`, `type`, `subtype`, `owner_guid`, `site_guid`, `container_guid`, `access_id`, `time_created`, `time_updated`, `last_action`, `enabled`) VALUES
(1, 'site', 0, 0, 1, 0, 2, 1323866763, 1323867608, 1323866763, 'yes'),
(2, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(3, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(4, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(5, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(6, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(7, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(8, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(9, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(10, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(11, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(12, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(13, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(14, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(15, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(16, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(17, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(18, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(19, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(20, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(21, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(22, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(23, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(24, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(25, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(26, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(27, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(28, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(29, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(30, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(31, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(32, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(33, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(34, 'object', 2, 1, 1, 1, 2, 1323866763, 1323866763, 1323866763, 'yes'),
(35, 'user', 0, 0, 1, 0, 2, 1323866797, 1323876871, 1323866797, 'yes'),
(36, 'object', 3, 35, 1, 35, 2, 1323866797, 1323866797, 1323866797, 'yes'),
(37, 'object', 3, 35, 1, 35, 2, 1323866797, 1323866797, 1323866797, 'yes'),
(38, 'object', 3, 35, 1, 35, 2, 1323866797, 1323866797, 1323866797, 'yes'),
(39, 'object', 3, 35, 1, 35, 2, 1323866797, 1323866797, 1323866797, 'yes'),
(40, 'object', 4, 35, 1, 35, 2, 1323868061, 1323868600, 1323868061, 'yes'),
(41, 'user', 0, 0, 1, 0, 2, 1323867653, 1323867653, 1323867653, 'yes'),
(42, 'object', 6, 35, 1, 35, 2, 1323867783, 1323867783, 1323867783, 'yes'),
(43, 'object', 6, 35, 1, 35, 2, 1323867811, 1323867811, 1323867811, 'yes'),
(44, 'object', 1, 35, 1, 35, 2, 1323867901, 1323867901, 1323867901, 'yes'),
(45, 'object', 4, 35, 1, 35, 2, 1323868075, 1323868075, 1323868075, 'yes'),
(46, 'user', 0, 0, 1, 0, 2, 1323869176, 1323869176, 1323869176, 'yes'),
(47, 'object', 3, 41, 1, 41, 2, 1323869197, 1323869197, 1323869197, 'yes'),
(48, 'object', 3, 41, 1, 41, 2, 1323869197, 1323869197, 1323869197, 'yes'),
(49, 'object', 3, 41, 1, 41, 2, 1323869197, 1323869197, 1323869197, 'yes'),
(50, 'object', 3, 41, 1, 41, 2, 1323869197, 1323869197, 1323869197, 'yes'),
(51, 'group', 0, 35, 1, 35, 2, 1323869310, 1323869386, 1323869310, 'yes'),
(52, 'object', 5, 35, 1, 35, 2, 1323876974, 1323876974, 1323876974, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `elgg_entity_relationships`
--

DROP TABLE IF EXISTS `elgg_entity_relationships`;
CREATE TABLE IF NOT EXISTS `elgg_entity_relationships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid_one` bigint(20) unsigned NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `guid_two` bigint(20) unsigned NOT NULL,
  `time_created` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid_one` (`guid_one`,`relationship`,`guid_two`),
  KEY `relationship` (`relationship`),
  KEY `guid_two` (`guid_two`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `elgg_entity_relationships`
--

INSERT INTO `elgg_entity_relationships` (`id`, `guid_one`, `relationship`, `guid_two`, `time_created`) VALUES
(1, 2, 'active_plugin', 1, 1323866763),
(2, 3, 'active_plugin', 1, 1323866763),
(3, 11, 'active_plugin', 1, 1323866763),
(4, 12, 'active_plugin', 1, 1323866763),
(5, 13, 'active_plugin', 1, 1323866763),
(6, 14, 'active_plugin', 1, 1323866763),
(7, 15, 'active_plugin', 1, 1323866763),
(8, 16, 'active_plugin', 1, 1323866763),
(9, 17, 'active_plugin', 1, 1323866763),
(10, 18, 'active_plugin', 1, 1323866763),
(11, 19, 'active_plugin', 1, 1323866763),
(12, 20, 'active_plugin', 1, 1323866763),
(13, 21, 'active_plugin', 1, 1323866763),
(14, 22, 'active_plugin', 1, 1323866763),
(15, 24, 'active_plugin', 1, 1323866763),
(16, 25, 'active_plugin', 1, 1323866763),
(17, 26, 'active_plugin', 1, 1323866763),
(18, 27, 'active_plugin', 1, 1323866763),
(19, 29, 'active_plugin', 1, 1323866763),
(20, 30, 'active_plugin', 1, 1323866764),
(21, 33, 'active_plugin', 1, 1323866764),
(22, 34, 'active_plugin', 1, 1323866764),
(23, 35, 'member_of_site', 1, 1323866797),
(24, 41, 'member_of_site', 1, 1323867653),
(25, 46, 'member_of_site', 1, 1323869176),
(26, 35, 'member', 51, 1323869310);

-- --------------------------------------------------------

--
-- Table structure for table `elgg_entity_subtypes`
--

DROP TABLE IF EXISTS `elgg_entity_subtypes`;
CREATE TABLE IF NOT EXISTS `elgg_entity_subtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('object','user','group','site') NOT NULL,
  `subtype` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`,`subtype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `elgg_entity_subtypes`
--

INSERT INTO `elgg_entity_subtypes` (`id`, `type`, `subtype`, `class`) VALUES
(1, 'object', 'file', 'ElggFile'),
(2, 'object', 'plugin', 'ElggPlugin'),
(3, 'object', 'widget', 'ElggWidget'),
(4, 'object', 'blog', 'ElggBlog'),
(5, 'object', 'thewire', 'ElggWire'),
(6, 'object', 'bookmarks', '');

-- --------------------------------------------------------

--
-- Table structure for table `elgg_geocode_cache`
--

DROP TABLE IF EXISTS `elgg_geocode_cache`;
CREATE TABLE IF NOT EXISTS `elgg_geocode_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(128) DEFAULT NULL,
  `lat` varchar(20) DEFAULT NULL,
  `long` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `location` (`location`)
) ENGINE=MEMORY DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `elgg_geocode_cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `elgg_groups_entity`
--

DROP TABLE IF EXISTS `elgg_groups_entity`;
CREATE TABLE IF NOT EXISTS `elgg_groups_entity` (
  `guid` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`guid`),
  KEY `name` (`name`(50)),
  KEY `description` (`description`(50)),
  FULLTEXT KEY `name_2` (`name`,`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `elgg_groups_entity`
--

INSERT INTO `elgg_groups_entity` (`guid`, `name`, `description`) VALUES
(51, 'Los de TPI', '<p>Aca hay un rejunte de la gente que de algun modo se siente identificada por las siglas T.P.I.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `elgg_hmac_cache`
--

DROP TABLE IF EXISTS `elgg_hmac_cache`;
CREATE TABLE IF NOT EXISTS `elgg_hmac_cache` (
  `hmac` varchar(255) NOT NULL,
  `ts` int(11) NOT NULL,
  PRIMARY KEY (`hmac`),
  KEY `ts` (`ts`)
) ENGINE=MEMORY DEFAULT CHARSET=latin1;

--
-- Dumping data for table `elgg_hmac_cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `elgg_metadata`
--

DROP TABLE IF EXISTS `elgg_metadata`;
CREATE TABLE IF NOT EXISTS `elgg_metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity_guid` bigint(20) unsigned NOT NULL,
  `name_id` int(11) NOT NULL,
  `value_id` int(11) NOT NULL,
  `value_type` enum('integer','text') NOT NULL,
  `owner_guid` bigint(20) unsigned NOT NULL,
  `access_id` int(11) NOT NULL,
  `time_created` int(11) NOT NULL,
  `enabled` enum('yes','no') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`),
  KEY `entity_guid` (`entity_guid`),
  KEY `name_id` (`name_id`),
  KEY `value_id` (`value_id`),
  KEY `owner_guid` (`owner_guid`),
  KEY `access_id` (`access_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=70 ;

--
-- Dumping data for table `elgg_metadata`
--

INSERT INTO `elgg_metadata` (`id`, `entity_guid`, `name_id`, `value_id`, `value_type`, `owner_guid`, `access_id`, `time_created`, `enabled`) VALUES
(10, 1, 1, 8, 'text', 35, 2, 1323867608, 'yes'),
(2, 35, 3, 4, 'text', 35, 2, 1323866797, 'yes'),
(3, 35, 5, 4, 'text', 0, 2, 1323866797, 'yes'),
(4, 35, 6, 7, 'text', 0, 2, 1323866797, 'yes'),
(44, 40, 9, 50, 'text', 35, 2, 1323868600, 'yes'),
(46, 40, 11, 48, 'text', 35, 2, 1323868600, 'yes'),
(48, 46, 54, 4, 'text', 46, 2, 1323869176, 'yes'),
(11, 41, 3, 4, 'text', 41, 2, 1323867653, 'yes'),
(47, 46, 3, 4, 'text', 46, 2, 1323869176, 'yes'),
(13, 41, 5, 4, 'text', 35, 2, 1323867653, 'yes'),
(14, 41, 6, 53, 'text', 35, 2, 1323867653, 'yes'),
(15, 42, 20, 21, 'text', 35, 2, 1323867783, 'yes'),
(16, 42, 22, 23, 'text', 35, 2, 1323867783, 'yes'),
(17, 43, 20, 24, 'text', 35, 2, 1323867811, 'yes'),
(18, 43, 22, 25, 'text', 35, 2, 1323867811, 'yes'),
(19, 44, 22, 2, 'text', 35, 2, 1323867901, 'yes'),
(20, 44, 26, 27, 'text', 35, 2, 1323867901, 'yes'),
(21, 44, 28, 29, 'text', 35, 2, 1323867901, 'yes'),
(22, 44, 30, 31, 'text', 35, 2, 1323867901, 'yes'),
(23, 44, 32, 33, 'text', 35, 2, 1323867901, 'yes'),
(24, 44, 34, 35, 'text', 35, 2, 1323867901, 'yes'),
(25, 44, 36, 37, 'text', 35, 2, 1323867901, 'yes'),
(26, 44, 38, 39, 'text', 35, 2, 1323867901, 'yes'),
(27, 44, 40, 41, 'text', 35, 2, 1323867901, 'yes'),
(28, 44, 42, 43, 'text', 35, 2, 1323867901, 'yes'),
(41, 45, 9, 50, 'text', 35, 2, 1323868075, 'yes'),
(42, 45, 45, 46, 'text', 35, 2, 1323868075, 'yes'),
(43, 45, 11, 51, 'text', 35, 2, 1323868075, 'yes'),
(45, 40, 45, 46, 'text', 35, 2, 1323868600, 'yes'),
(49, 46, 55, 56, 'text', 46, 2, 1323869176, 'yes'),
(59, 51, 57, 2, 'text', 35, 2, 1323869386, 'yes'),
(60, 51, 58, 59, 'text', 35, 2, 1323869386, 'yes'),
(61, 51, 60, 59, 'text', 35, 2, 1323869386, 'yes'),
(62, 51, 61, 59, 'text', 35, 2, 1323869386, 'yes'),
(63, 51, 62, 59, 'text', 35, 2, 1323869386, 'yes'),
(64, 51, 63, 59, 'text', 35, 2, 1323869386, 'yes'),
(65, 51, 64, 59, 'text', 35, 2, 1323869386, 'yes'),
(66, 51, 65, 66, 'integer', 35, 2, 1323869386, 'yes'),
(58, 51, 67, 68, 'integer', 35, 2, 1323869310, 'yes'),
(67, 51, 69, 70, 'integer', 35, 2, 1323869386, 'yes'),
(68, 52, 71, 72, 'text', 35, 2, 1323876974, 'yes'),
(69, 52, 73, 74, 'integer', 35, 2, 1323876974, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `elgg_metastrings`
--

DROP TABLE IF EXISTS `elgg_metastrings`;
CREATE TABLE IF NOT EXISTS `elgg_metastrings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `string` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `string` (`string`(50))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=75 ;

--
-- Dumping data for table `elgg_metastrings`
--

INSERT INTO `elgg_metastrings` (`id`, `string`) VALUES
(1, 'email'),
(2, ''),
(3, 'notification:method:email'),
(4, '1'),
(5, 'validated'),
(6, 'validated_method'),
(7, 'admin_user'),
(8, 'unq-elgg@unq.edu.ar'),
(9, 'status'),
(10, 'unsaved_draft'),
(11, 'excerpt'),
(12, 'Hola Gente!\r\nBienvenidos al super sitio de UNQ-Elgg. Espero que les guste esta alternativa a una red social. Que estan esperando para crear su usuario????!!!!'),
(13, 'new_post'),
(14, '<p>Hola Gente!</p>\r\n<p>Bienvenidos al super sitio de UNQ-Elgg. Espero que les guste esta alternativa a una red social. Que estan esperando para crear su usuario????!!!!</p>'),
(15, 'blog_auto_save'),
(16, '<p>Hola Gente!</p>\r\n<p>Bienvenidos al super sitio de UNQ-Elgg. Espero que les guste esta alternativa a una red social. Que estan esperando para crear su usuario????!!!!</p>\r\n<p>&nbsp;</p>\r\n<p>Saludos,</p>\r\n<p>Andres, el Colo y </p>'),
(17, 'disable_reason'),
(18, 'uservalidationbyemail_new_user'),
(19, '0'),
(20, 'address'),
(21, 'http://cronos.unq.edu.ar'),
(22, 'tags'),
(23, 'cronobiologia'),
(24, 'http://www.phdcomics.com'),
(25, 'comics'),
(26, 'filename'),
(27, 'file/1323867900baby_turtle.jpg'),
(28, 'mimetype'),
(29, 'image/jpeg'),
(30, 'originalfilename'),
(31, 'baby_turtle.jpg'),
(32, 'simpletype'),
(33, 'image'),
(34, 'filestore::dir_root'),
(35, '/usr/local/elgg/data/'),
(36, 'filestore::filestore'),
(37, 'ElggDiskFilestore'),
(38, 'thumbnail'),
(39, 'file/thumb1323867900baby_turtle.jpg'),
(40, 'smallthumb'),
(41, 'file/smallthumb1323867900baby_turtle.jpg'),
(42, 'largethumb'),
(43, 'file/largethumb1323867900baby_turtle.jpg'),
(44, 'draft'),
(45, 'comments_on'),
(46, 'On'),
(47, 'Eh... loco, media pila sumense!\r\nEn cualquier momento empiezo a repartir choripanes'),
(48, 'Hola Gente! Bienvenidos al super sitio de UNQ-Elgg. Espero que les guste esta alternativa a una red social. Que estan esperando para crear su usuario????!!!!'),
(49, 'blog_revision'),
(50, 'published'),
(51, 'Eh... loco, media pila sumense! En cualquier momento empiezo a repartir choripanes'),
(52, '<p>Eh... loco, media pila sumense!</p>\r\n<p>En cualquier momento empiezo a repartir choripanes</p>'),
(53, 'manual'),
(54, 'admin_created'),
(55, 'created_by_guid'),
(56, '35'),
(57, 'briefdescription'),
(58, 'blog_enable'),
(59, 'yes'),
(60, 'bookmarks_enable'),
(61, 'file_enable'),
(62, 'activity_enable'),
(63, 'forum_enable'),
(64, 'pages_enable'),
(65, 'membership'),
(66, '2'),
(67, 'group_acl'),
(68, '3'),
(69, 'icontime'),
(70, '1323869386'),
(71, 'method'),
(72, 'site'),
(73, 'wire_thread'),
(74, '52');

-- --------------------------------------------------------

--
-- Table structure for table `elgg_objects_entity`
--

DROP TABLE IF EXISTS `elgg_objects_entity`;
CREATE TABLE IF NOT EXISTS `elgg_objects_entity` (
  `guid` bigint(20) unsigned NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`guid`),
  FULLTEXT KEY `title` (`title`,`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `elgg_objects_entity`
--

INSERT INTO `elgg_objects_entity` (`guid`, `title`, `description`) VALUES
(2, 'blog', ''),
(3, 'bookmarks', ''),
(4, 'categories', ''),
(5, 'custom_index', ''),
(6, 'dashboard', ''),
(7, 'developers', ''),
(8, 'diagnostics', ''),
(9, 'embed', ''),
(10, 'externalpages', ''),
(11, 'file', ''),
(12, 'garbagecollector', ''),
(13, 'groups', ''),
(14, 'htmlawed', ''),
(15, 'invitefriends', ''),
(16, 'likes', ''),
(17, 'logbrowser', ''),
(18, 'logrotate', ''),
(19, 'members', ''),
(20, 'messageboard', ''),
(21, 'messages', ''),
(22, 'notifications', ''),
(23, 'oauth_api', ''),
(24, 'pages', ''),
(25, 'profile', ''),
(26, 'reportedcontent', ''),
(27, 'search', ''),
(28, 'tagcloud', ''),
(29, 'thewire', ''),
(30, 'tinymce', ''),
(31, 'twitter', ''),
(32, 'twitter_api', ''),
(33, 'uservalidationbyemail', ''),
(34, 'zaudio', ''),
(36, '', ''),
(37, '', ''),
(38, '', ''),
(39, '', ''),
(40, 'Bienvenidos a UNQ-Elgg', '<p>Hola Gente!</p>\r\n<p>Bienvenidos al super sitio de UNQ-Elgg. Espero que les guste esta alternativa a una red social. Que estan esperando para crear su usuario????!!!!</p>\r\n<p>Hola Gente!</p>\r\n<p>Bienvenidos al super sitio de UNQ-Elgg. Espero que les guste esta alternativa a una red social. Que estan esperando para crear su usuario????!!!!</p>\r\n<p>&nbsp;</p>\r\n<p>Saludos,</p>\r\n<p>Andres, el Colo y Alejandro</p>'),
(42, 'La pagina del labo de cronobiologia', ''),
(43, 'PhD Comics', ''),
(44, 'Tortuga naciendo', ''),
(45, 'Todavia no hay nadie!!!', '<p>Eh... loco, media pila sumense!</p>\r\n<p>En cualquier momento empiezo a repartir choripanes</p>'),
(47, '', ''),
(48, '', ''),
(49, '', ''),
(50, '', ''),
(52, '', 'El Elgg de la UNQ se va para arriba! Ya se sumaron el Colo y Alejandro.');

-- --------------------------------------------------------

--
-- Table structure for table `elgg_private_settings`
--

DROP TABLE IF EXISTS `elgg_private_settings`;
CREATE TABLE IF NOT EXISTS `elgg_private_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity_guid` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entity_guid` (`entity_guid`,`name`),
  KEY `name` (`name`),
  KEY `value` (`value`(50))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=69 ;

--
-- Dumping data for table `elgg_private_settings`
--

INSERT INTO `elgg_private_settings` (`id`, `entity_guid`, `name`, `value`) VALUES
(1, 2, 'elgg:internal:priority', '1'),
(2, 3, 'elgg:internal:priority', '2'),
(3, 4, 'elgg:internal:priority', '3'),
(4, 5, 'elgg:internal:priority', '4'),
(5, 6, 'elgg:internal:priority', '5'),
(6, 7, 'elgg:internal:priority', '6'),
(7, 8, 'elgg:internal:priority', '7'),
(8, 9, 'elgg:internal:priority', '8'),
(9, 10, 'elgg:internal:priority', '9'),
(10, 11, 'elgg:internal:priority', '10'),
(11, 12, 'elgg:internal:priority', '11'),
(12, 13, 'elgg:internal:priority', '12'),
(13, 14, 'elgg:internal:priority', '13'),
(14, 15, 'elgg:internal:priority', '14'),
(15, 16, 'elgg:internal:priority', '15'),
(16, 17, 'elgg:internal:priority', '16'),
(17, 18, 'elgg:internal:priority', '17'),
(18, 19, 'elgg:internal:priority', '18'),
(19, 20, 'elgg:internal:priority', '19'),
(20, 21, 'elgg:internal:priority', '20'),
(21, 22, 'elgg:internal:priority', '21'),
(22, 23, 'elgg:internal:priority', '22'),
(23, 24, 'elgg:internal:priority', '23'),
(24, 25, 'elgg:internal:priority', '24'),
(25, 26, 'elgg:internal:priority', '25'),
(26, 27, 'elgg:internal:priority', '26'),
(27, 28, 'elgg:internal:priority', '27'),
(28, 29, 'elgg:internal:priority', '28'),
(29, 30, 'elgg:internal:priority', '29'),
(30, 31, 'elgg:internal:priority', '30'),
(31, 32, 'elgg:internal:priority', '31'),
(32, 33, 'elgg:internal:priority', '32'),
(33, 34, 'elgg:internal:priority', '33'),
(34, 36, 'handler', 'admin_welcome'),
(35, 36, 'context', 'admin'),
(36, 36, 'column', '1'),
(37, 36, 'order', '0'),
(38, 37, 'handler', 'online_users'),
(39, 37, 'context', 'admin'),
(40, 37, 'column', '2'),
(41, 37, 'order', '20'),
(42, 38, 'handler', 'new_users'),
(43, 38, 'context', 'admin'),
(44, 38, 'order', '30'),
(45, 38, 'column', '2'),
(46, 39, 'handler', 'content_stats'),
(47, 39, 'context', 'admin'),
(48, 39, 'order', '40'),
(49, 39, 'column', '2'),
(50, 37, 'num_display', '8'),
(51, 38, 'num_display', '5'),
(52, 39, 'num_display', '8'),
(53, 47, 'handler', 'admin_welcome'),
(54, 47, 'context', 'admin'),
(55, 47, 'order', '-10'),
(56, 47, 'column', '1'),
(57, 48, 'handler', 'online_users'),
(58, 48, 'context', 'admin'),
(59, 48, 'order', '-10'),
(60, 48, 'column', '2'),
(61, 49, 'handler', 'new_users'),
(62, 49, 'context', 'admin'),
(63, 49, 'order', ''),
(64, 49, 'column', '2'),
(65, 50, 'handler', 'content_stats'),
(66, 50, 'context', 'admin'),
(67, 50, 'order', '10'),
(68, 50, 'column', '2');

-- --------------------------------------------------------

--
-- Table structure for table `elgg_river`
--

DROP TABLE IF EXISTS `elgg_river`;
CREATE TABLE IF NOT EXISTS `elgg_river` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(8) NOT NULL,
  `subtype` varchar(32) NOT NULL,
  `action_type` varchar(32) NOT NULL,
  `access_id` int(11) NOT NULL,
  `view` text NOT NULL,
  `subject_guid` int(11) NOT NULL,
  `object_guid` int(11) NOT NULL,
  `annotation_id` int(11) NOT NULL,
  `posted` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `action_type` (`action_type`),
  KEY `access_id` (`access_id`),
  KEY `subject_guid` (`subject_guid`),
  KEY `object_guid` (`object_guid`),
  KEY `annotation_id` (`annotation_id`),
  KEY `posted` (`posted`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `elgg_river`
--

INSERT INTO `elgg_river` (`id`, `type`, `subtype`, `action_type`, `access_id`, `view`, `subject_guid`, `object_guid`, `annotation_id`, `posted`) VALUES
(1, 'object', 'bookmarks', 'create', 2, 'river/object/bookmarks/create', 35, 42, 0, 1323867783),
(2, 'object', 'bookmarks', 'create', 2, 'river/object/bookmarks/create', 35, 43, 0, 1323867811),
(3, 'object', 'file', 'create', 2, 'river/object/file/create', 35, 44, 0, 1323867901),
(4, 'object', 'blog', 'create', 2, 'river/object/blog/create', 35, 40, 0, 1323868061),
(5, 'object', 'blog', 'create', 2, 'river/object/blog/create', 35, 45, 0, 1323868075),
(6, 'group', '', 'create', 2, 'river/group/create', 35, 51, 0, 1323869310),
(7, 'object', 'thewire', 'create', 2, 'river/object/thewire/create', 35, 52, 0, 1323876974);

-- --------------------------------------------------------

--
-- Table structure for table `elgg_sites_entity`
--

DROP TABLE IF EXISTS `elgg_sites_entity`;
CREATE TABLE IF NOT EXISTS `elgg_sites_entity` (
  `guid` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `url` (`url`),
  FULLTEXT KEY `name` (`name`,`description`,`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `elgg_sites_entity`
--

INSERT INTO `elgg_sites_entity` (`guid`, `name`, `description`, `url`) VALUES
(1, 'UNQ-Elgg', 'Esta es la red social de Laboratorio de Sistemas Operativos y Redes - 2011', 'http://192.168.1.102/');

-- --------------------------------------------------------

--
-- Table structure for table `elgg_system_log`
--

DROP TABLE IF EXISTS `elgg_system_log`;
CREATE TABLE IF NOT EXISTS `elgg_system_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `object_class` varchar(50) NOT NULL,
  `object_type` varchar(50) NOT NULL,
  `object_subtype` varchar(50) NOT NULL,
  `event` varchar(50) NOT NULL,
  `performed_by_guid` int(11) NOT NULL,
  `owner_guid` int(11) NOT NULL,
  `access_id` int(11) NOT NULL,
  `enabled` enum('yes','no') NOT NULL DEFAULT 'yes',
  `time_created` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `object_class` (`object_class`),
  KEY `object_type` (`object_type`),
  KEY `object_subtype` (`object_subtype`),
  KEY `event` (`event`),
  KEY `performed_by_guid` (`performed_by_guid`),
  KEY `access_id` (`access_id`),
  KEY `time_created` (`time_created`),
  KEY `river_key` (`object_type`,`object_subtype`,`event`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=201 ;

--
-- Dumping data for table `elgg_system_log`
--

INSERT INTO `elgg_system_log` (`id`, `object_id`, `object_class`, `object_type`, `object_subtype`, `event`, `performed_by_guid`, `owner_guid`, `access_id`, `enabled`, `time_created`) VALUES
(1, 1, 'ElggMetadata', 'metadata', 'email', 'create', 0, 0, 2, 'yes', 1323866763),
(2, 2, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(3, 3, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(4, 4, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(5, 5, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(6, 6, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(7, 7, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(8, 8, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(9, 9, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(10, 10, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(11, 11, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(12, 12, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(13, 13, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(14, 14, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(15, 15, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(16, 16, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(17, 17, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(18, 18, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(19, 19, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(20, 20, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(21, 21, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(22, 22, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(23, 23, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(24, 24, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(25, 25, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(26, 26, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(27, 27, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(28, 28, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(29, 29, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(30, 30, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(31, 31, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(32, 32, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(33, 33, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(34, 34, 'ElggPlugin', 'object', 'plugin', 'create', 0, 1, 2, 'yes', 1323866763),
(35, 20, 'ElggRelationship', 'relationship', 'active_plugin', 'create', 0, 0, 2, 'yes', 1323866764),
(36, 21, 'ElggRelationship', 'relationship', 'active_plugin', 'create', 0, 0, 2, 'yes', 1323866764),
(37, 22, 'ElggRelationship', 'relationship', 'active_plugin', 'create', 0, 0, 2, 'yes', 1323866764),
(38, 23, 'ElggRelationship', 'relationship', 'member_of_site', 'create', 0, 0, 2, 'yes', 1323866797),
(39, 35, 'ElggUser', 'user', '', 'create', 0, 0, 2, 'yes', 1323866797),
(40, 2, 'ElggMetadata', 'metadata', 'notification:method:email', 'create', 0, 35, 2, 'yes', 1323866797),
(41, 36, 'ElggWidget', 'object', 'widget', 'create', 0, 35, 2, 'yes', 1323866797),
(42, 37, 'ElggWidget', 'object', 'widget', 'create', 0, 35, 2, 'yes', 1323866797),
(43, 38, 'ElggWidget', 'object', 'widget', 'create', 0, 35, 2, 'yes', 1323866797),
(44, 39, 'ElggWidget', 'object', 'widget', 'create', 0, 35, 2, 'yes', 1323866797),
(45, 35, 'ElggUser', 'user', '', 'make_admin', 0, 0, 2, 'yes', 1323866797),
(46, 3, 'ElggMetadata', 'metadata', 'validated', 'create', 0, 0, 2, 'yes', 1323866797),
(47, 4, 'ElggMetadata', 'metadata', 'validated_method', 'create', 0, 0, 2, 'yes', 1323866797),
(48, 35, 'ElggUser', 'user', '', 'update', 35, 0, 2, 'yes', 1323866797),
(49, 35, 'ElggUser', 'user', '', 'login', 35, 0, 2, 'yes', 1323866797),
(50, 1, 'ElggMetadata', 'metadata', 'email', 'delete', 35, 0, 2, 'yes', 1323866914),
(51, 5, 'ElggMetadata', 'metadata', 'email', 'create', 35, 35, 2, 'yes', 1323866914),
(52, 1, 'ElggSite', 'site', '', 'update', 35, 0, 2, 'yes', 1323866914),
(53, 6, 'ElggMetadata', 'metadata', 'status', 'create', 35, 35, 0, 'yes', 1323867327),
(54, 7, 'ElggMetadata', 'metadata', 'excerpt', 'create', 35, 35, 0, 'yes', 1323867327),
(55, 8, 'ElggMetadata', 'metadata', 'new_post', 'create', 35, 35, 0, 'yes', 1323867327),
(56, 40, 'ElggBlog', 'object', 'blog', 'create', 35, 35, 0, 'yes', 1323867327),
(57, 40, 'ElggBlog', 'object', 'blog', 'annotate', 35, 35, 0, 'yes', 1323867327),
(58, 1, 'ElggAnnotation', 'annotation', 'blog_auto_save', 'create', 35, 35, 0, 'yes', 1323867327),
(59, 1, 'ElggAnnotation', 'annotation', 'blog_auto_save', 'delete', 35, 35, 0, 'yes', 1323867387),
(60, 40, 'ElggBlog', 'object', 'blog', 'annotate', 35, 35, 0, 'yes', 1323867387),
(61, 2, 'ElggAnnotation', 'annotation', 'blog_auto_save', 'create', 35, 35, 0, 'yes', 1323867387),
(62, 5, 'ElggMetadata', 'metadata', 'email', 'delete', 35, 35, 2, 'yes', 1323867601),
(63, 9, 'ElggMetadata', 'metadata', 'email', 'create', 35, 35, 2, 'yes', 1323867601),
(64, 1, 'ElggSite', 'site', '', 'update', 35, 0, 2, 'yes', 1323867601),
(65, 9, 'ElggMetadata', 'metadata', 'email', 'delete', 35, 35, 2, 'yes', 1323867608),
(66, 10, 'ElggMetadata', 'metadata', 'email', 'create', 35, 35, 2, 'yes', 1323867608),
(67, 1, 'ElggSite', 'site', '', 'update', 35, 0, 2, 'yes', 1323867608),
(68, 35, 'ElggUser', 'user', '', 'logout', 35, 0, 2, 'yes', 1323867625),
(69, 35, 'ElggUser', 'user', '', 'update', 35, 0, 2, 'yes', 1323867625),
(70, 24, 'ElggRelationship', 'relationship', 'member_of_site', 'create', 0, 0, 2, 'yes', 1323867653),
(71, 41, 'ElggUser', 'user', '', 'create', 0, 0, 2, 'yes', 1323867653),
(72, 11, 'ElggMetadata', 'metadata', 'notification:method:email', 'create', 0, 41, 2, 'yes', 1323867653),
(73, 41, 'ElggUser', 'user', '', 'disable', 0, 0, 2, 'yes', 1323867653),
(74, 12, 'ElggMetadata', 'metadata', 'disable_reason', 'create', 0, 0, 2, 'yes', 1323867653),
(75, 11, 'ElggMetadata', 'metadata', 'notification:method:email', 'disable', 0, 41, 2, 'yes', 1323867653),
(76, 12, 'ElggMetadata', 'metadata', 'disable_reason', 'disable', 0, 0, 2, 'yes', 1323867653),
(77, 13, 'ElggMetadata', 'metadata', 'validated', 'create', 0, 0, 2, 'yes', 1323867653),
(78, 14, 'ElggMetadata', 'metadata', 'validated_method', 'create', 0, 0, 2, 'yes', 1323867653),
(79, 35, 'ElggUser', 'user', '', 'update', 35, 0, 2, 'yes', 1323867735),
(80, 35, 'ElggUser', 'user', '', 'login', 35, 0, 2, 'yes', 1323867735),
(81, 15, 'ElggMetadata', 'metadata', 'address', 'create', 35, 35, 2, 'yes', 1323867783),
(82, 16, 'ElggMetadata', 'metadata', 'tags', 'create', 35, 35, 2, 'yes', 1323867783),
(83, 42, 'ElggObject', 'object', 'bookmarks', 'create', 35, 35, 2, 'yes', 1323867783),
(84, 17, 'ElggMetadata', 'metadata', 'address', 'create', 35, 35, 2, 'yes', 1323867811),
(85, 18, 'ElggMetadata', 'metadata', 'tags', 'create', 35, 35, 2, 'yes', 1323867811),
(86, 43, 'ElggObject', 'object', 'bookmarks', 'create', 35, 35, 2, 'yes', 1323867811),
(87, 19, 'ElggMetadata', 'metadata', 'tags', 'create', 35, 35, 2, 'yes', 1323867901),
(88, 20, 'ElggMetadata', 'metadata', 'filename', 'create', 35, 35, 2, 'yes', 1323867901),
(89, 21, 'ElggMetadata', 'metadata', 'mimetype', 'create', 35, 35, 2, 'yes', 1323867901),
(90, 22, 'ElggMetadata', 'metadata', 'originalfilename', 'create', 35, 35, 2, 'yes', 1323867901),
(91, 23, 'ElggMetadata', 'metadata', 'simpletype', 'create', 35, 35, 2, 'yes', 1323867901),
(92, 44, 'ElggFile', 'object', 'file', 'create', 35, 35, 2, 'yes', 1323867901),
(93, 24, 'ElggMetadata', 'metadata', 'filestore::dir_root', 'create', 35, 35, 2, 'yes', 1323867901),
(94, 25, 'ElggMetadata', 'metadata', 'filestore::filestore', 'create', 35, 35, 2, 'yes', 1323867901),
(95, 26, 'ElggMetadata', 'metadata', 'thumbnail', 'create', 35, 35, 2, 'yes', 1323867901),
(96, 27, 'ElggMetadata', 'metadata', 'smallthumb', 'create', 35, 35, 2, 'yes', 1323867901),
(97, 28, 'ElggMetadata', 'metadata', 'largethumb', 'create', 35, 35, 2, 'yes', 1323867901),
(98, 29, 'ElggMetadata', 'metadata', 'status', 'create', 35, 35, 2, 'yes', 1323867952),
(99, 30, 'ElggMetadata', 'metadata', 'comments_on', 'create', 35, 35, 2, 'yes', 1323867952),
(100, 31, 'ElggMetadata', 'metadata', 'excerpt', 'create', 35, 35, 2, 'yes', 1323867952),
(101, 45, 'ElggBlog', 'object', 'blog', 'create', 35, 35, 2, 'yes', 1323867952),
(102, 6, 'ElggMetadata', 'metadata', 'status', 'delete', 35, 35, 0, 'yes', 1323868010),
(103, 32, 'ElggMetadata', 'metadata', 'status', 'create', 35, 35, 0, 'yes', 1323868010),
(104, 33, 'ElggMetadata', 'metadata', 'comments_on', 'create', 35, 35, 1, 'yes', 1323868010),
(105, 7, 'ElggMetadata', 'metadata', 'excerpt', 'delete', 35, 35, 0, 'yes', 1323868010),
(106, 34, 'ElggMetadata', 'metadata', 'excerpt', 'create', 35, 35, 1, 'yes', 1323868010),
(107, 40, 'ElggBlog', 'object', 'blog', 'update', 35, 35, 0, 'yes', 1323868010),
(108, 2, 'ElggAnnotation', 'annotation', 'blog_auto_save', 'delete', 35, 35, 0, 'yes', 1323868010),
(109, 8, 'ElggMetadata', 'metadata', 'new_post', 'delete', 35, 35, 1, 'yes', 1323868010),
(110, 32, 'ElggMetadata', 'metadata', 'status', 'delete', 35, 35, 1, 'yes', 1323868027),
(111, 35, 'ElggMetadata', 'metadata', 'status', 'create', 35, 35, 1, 'yes', 1323868027),
(112, 33, 'ElggMetadata', 'metadata', 'comments_on', 'delete', 35, 35, 1, 'yes', 1323868027),
(113, 36, 'ElggMetadata', 'metadata', 'comments_on', 'create', 35, 35, 2, 'yes', 1323868027),
(114, 34, 'ElggMetadata', 'metadata', 'excerpt', 'delete', 35, 35, 1, 'yes', 1323868027),
(115, 37, 'ElggMetadata', 'metadata', 'excerpt', 'create', 35, 35, 2, 'yes', 1323868027),
(116, 40, 'ElggBlog', 'object', 'blog', 'update', 35, 35, 1, 'yes', 1323868027),
(117, 40, 'ElggBlog', 'object', 'blog', 'annotate', 35, 35, 2, 'yes', 1323868027),
(118, 3, 'ElggAnnotation', 'annotation', 'blog_revision', 'create', 35, 35, 0, 'yes', 1323868027),
(119, 35, 'ElggMetadata', 'metadata', 'status', 'delete', 35, 35, 2, 'yes', 1323868061),
(120, 38, 'ElggMetadata', 'metadata', 'status', 'create', 35, 35, 2, 'yes', 1323868061),
(121, 36, 'ElggMetadata', 'metadata', 'comments_on', 'delete', 35, 35, 2, 'yes', 1323868061),
(122, 39, 'ElggMetadata', 'metadata', 'comments_on', 'create', 35, 35, 2, 'yes', 1323868061),
(123, 37, 'ElggMetadata', 'metadata', 'excerpt', 'delete', 35, 35, 2, 'yes', 1323868061),
(124, 40, 'ElggMetadata', 'metadata', 'excerpt', 'create', 35, 35, 2, 'yes', 1323868061),
(125, 40, 'ElggBlog', 'object', 'blog', 'update', 35, 35, 2, 'yes', 1323868061),
(126, 40, 'ElggBlog', 'object', 'blog', 'annotate', 35, 35, 2, 'yes', 1323868061),
(127, 4, 'ElggAnnotation', 'annotation', 'blog_revision', 'create', 35, 35, 0, 'yes', 1323868061),
(128, 29, 'ElggMetadata', 'metadata', 'status', 'delete', 35, 35, 2, 'yes', 1323868075),
(129, 41, 'ElggMetadata', 'metadata', 'status', 'create', 35, 35, 2, 'yes', 1323868075),
(130, 30, 'ElggMetadata', 'metadata', 'comments_on', 'delete', 35, 35, 2, 'yes', 1323868075),
(131, 42, 'ElggMetadata', 'metadata', 'comments_on', 'create', 35, 35, 2, 'yes', 1323868075),
(132, 31, 'ElggMetadata', 'metadata', 'excerpt', 'delete', 35, 35, 2, 'yes', 1323868075),
(133, 43, 'ElggMetadata', 'metadata', 'excerpt', 'create', 35, 35, 2, 'yes', 1323868075),
(134, 45, 'ElggBlog', 'object', 'blog', 'update', 35, 35, 2, 'yes', 1323868075),
(135, 45, 'ElggBlog', 'object', 'blog', 'annotate', 35, 35, 2, 'yes', 1323868075),
(136, 5, 'ElggAnnotation', 'annotation', 'blog_revision', 'create', 35, 35, 0, 'yes', 1323868075),
(137, 38, 'ElggMetadata', 'metadata', 'status', 'delete', 35, 35, 2, 'yes', 1323868600),
(138, 44, 'ElggMetadata', 'metadata', 'status', 'create', 35, 35, 2, 'yes', 1323868600),
(139, 39, 'ElggMetadata', 'metadata', 'comments_on', 'delete', 35, 35, 2, 'yes', 1323868600),
(140, 45, 'ElggMetadata', 'metadata', 'comments_on', 'create', 35, 35, 2, 'yes', 1323868600),
(141, 40, 'ElggMetadata', 'metadata', 'excerpt', 'delete', 35, 35, 2, 'yes', 1323868600),
(142, 46, 'ElggMetadata', 'metadata', 'excerpt', 'create', 35, 35, 2, 'yes', 1323868600),
(143, 40, 'ElggBlog', 'object', 'blog', 'update', 35, 35, 2, 'yes', 1323868600),
(144, 40, 'ElggBlog', 'object', 'blog', 'annotate', 35, 35, 2, 'yes', 1323868600),
(145, 6, 'ElggAnnotation', 'annotation', 'blog_revision', 'create', 35, 35, 0, 'yes', 1323868600),
(146, 35, 'ElggUser', 'user', '', 'update', 35, 0, 2, 'yes', 1323868622),
(147, 13, 'ElggMetadata', 'metadata', 'validated', 'update', 35, 35, 2, 'yes', 1323868674),
(148, 14, 'ElggMetadata', 'metadata', 'validated_method', 'update', 35, 35, 2, 'yes', 1323868674),
(149, 41, 'ElggUser', 'user', '', 'enable', 35, 0, 2, 'no', 1323868674),
(150, 12, 'ElggMetadata', 'metadata', 'disable_reason', 'delete', 35, 0, 2, 'no', 1323868674),
(151, 11, 'ElggMetadata', 'metadata', 'notification:method:email', 'enable', 35, 41, 2, 'no', 1323868674),
(152, 35, 'ElggUser', 'user', '', 'update', 35, 0, 2, 'yes', 1323869080),
(153, 25, 'ElggRelationship', 'relationship', 'member_of_site', 'create', 35, 0, 2, 'yes', 1323869176),
(154, 46, 'ElggUser', 'user', '', 'create', 35, 0, 2, 'yes', 1323869176),
(155, 47, 'ElggMetadata', 'metadata', 'notification:method:email', 'create', 35, 46, 2, 'yes', 1323869176),
(156, 46, 'ElggUser', 'user', '', 'update', 35, 0, 2, 'yes', 1323869176),
(157, 48, 'ElggMetadata', 'metadata', 'admin_created', 'create', 35, 46, 2, 'yes', 1323869176),
(158, 49, 'ElggMetadata', 'metadata', 'created_by_guid', 'create', 35, 46, 2, 'yes', 1323869176),
(159, 47, 'ElggWidget', 'object', 'widget', 'create', 35, 41, 2, 'yes', 1323869197),
(160, 48, 'ElggWidget', 'object', 'widget', 'create', 35, 41, 2, 'yes', 1323869197),
(161, 49, 'ElggWidget', 'object', 'widget', 'create', 35, 41, 2, 'yes', 1323869197),
(162, 50, 'ElggWidget', 'object', 'widget', 'create', 35, 41, 2, 'yes', 1323869197),
(163, 41, 'ElggUser', 'user', '', 'make_admin', 35, 0, 2, 'yes', 1323869197),
(164, 50, 'ElggMetadata', 'metadata', 'briefdescription', 'create', 35, 35, 2, 'yes', 1323869310),
(165, 51, 'ElggMetadata', 'metadata', 'blog_enable', 'create', 35, 35, 2, 'yes', 1323869310),
(166, 52, 'ElggMetadata', 'metadata', 'bookmarks_enable', 'create', 35, 35, 2, 'yes', 1323869310),
(167, 53, 'ElggMetadata', 'metadata', 'file_enable', 'create', 35, 35, 2, 'yes', 1323869310),
(168, 54, 'ElggMetadata', 'metadata', 'activity_enable', 'create', 35, 35, 2, 'yes', 1323869310),
(169, 55, 'ElggMetadata', 'metadata', 'forum_enable', 'create', 35, 35, 2, 'yes', 1323869310),
(170, 56, 'ElggMetadata', 'metadata', 'pages_enable', 'create', 35, 35, 2, 'yes', 1323869310),
(171, 57, 'ElggMetadata', 'metadata', 'membership', 'create', 35, 35, 2, 'yes', 1323869310),
(172, 58, 'ElggMetadata', 'metadata', 'group_acl', 'create', 35, 35, 2, 'yes', 1323869310),
(173, 26, 'ElggRelationship', 'relationship', 'member', 'create', 35, 0, 2, 'yes', 1323869310),
(174, 50, 'ElggMetadata', 'metadata', 'briefdescription', 'delete', 35, 35, 2, 'yes', 1323869386),
(175, 59, 'ElggMetadata', 'metadata', 'briefdescription', 'create', 35, 35, 2, 'yes', 1323869386),
(176, 51, 'ElggMetadata', 'metadata', 'blog_enable', 'delete', 35, 35, 2, 'yes', 1323869386),
(177, 60, 'ElggMetadata', 'metadata', 'blog_enable', 'create', 35, 35, 2, 'yes', 1323869386),
(178, 52, 'ElggMetadata', 'metadata', 'bookmarks_enable', 'delete', 35, 35, 2, 'yes', 1323869386),
(179, 61, 'ElggMetadata', 'metadata', 'bookmarks_enable', 'create', 35, 35, 2, 'yes', 1323869386),
(180, 53, 'ElggMetadata', 'metadata', 'file_enable', 'delete', 35, 35, 2, 'yes', 1323869386),
(181, 62, 'ElggMetadata', 'metadata', 'file_enable', 'create', 35, 35, 2, 'yes', 1323869386),
(182, 54, 'ElggMetadata', 'metadata', 'activity_enable', 'delete', 35, 35, 2, 'yes', 1323869386),
(183, 63, 'ElggMetadata', 'metadata', 'activity_enable', 'create', 35, 35, 2, 'yes', 1323869386),
(184, 55, 'ElggMetadata', 'metadata', 'forum_enable', 'delete', 35, 35, 2, 'yes', 1323869386),
(185, 64, 'ElggMetadata', 'metadata', 'forum_enable', 'create', 35, 35, 2, 'yes', 1323869386),
(186, 56, 'ElggMetadata', 'metadata', 'pages_enable', 'delete', 35, 35, 2, 'yes', 1323869386),
(187, 65, 'ElggMetadata', 'metadata', 'pages_enable', 'create', 35, 35, 2, 'yes', 1323869386),
(188, 57, 'ElggMetadata', 'metadata', 'membership', 'delete', 35, 35, 2, 'yes', 1323869386),
(189, 66, 'ElggMetadata', 'metadata', 'membership', 'create', 35, 35, 2, 'yes', 1323869386),
(190, 51, 'ElggGroup', 'group', '', 'update', 35, 35, 2, 'yes', 1323869386),
(191, 67, 'ElggMetadata', 'metadata', 'icontime', 'create', 35, 35, 2, 'yes', 1323869386),
(192, 35, 'ElggUser', 'user', '', 'update', 35, 0, 2, 'yes', 1323870566),
(193, 35, 'ElggUser', 'user', '', 'login', 35, 0, 2, 'yes', 1323870566),
(194, 35, 'ElggUser', 'user', '', 'logout', 35, 0, 2, 'yes', 1323871403),
(195, 35, 'ElggUser', 'user', '', 'update', 35, 0, 2, 'yes', 1323871403),
(196, 35, 'ElggUser', 'user', '', 'update', 35, 0, 2, 'yes', 1323876871),
(197, 35, 'ElggUser', 'user', '', 'login', 35, 0, 2, 'yes', 1323876871),
(198, 68, 'ElggMetadata', 'metadata', 'method', 'create', 35, 35, 2, 'yes', 1323876974),
(199, 52, 'ElggWire', 'object', 'thewire', 'create', 35, 35, 2, 'yes', 1323876974),
(200, 69, 'ElggMetadata', 'metadata', 'wire_thread', 'create', 35, 35, 2, 'yes', 1323876974);

-- --------------------------------------------------------

--
-- Table structure for table `elgg_users_apisessions`
--

DROP TABLE IF EXISTS `elgg_users_apisessions`;
CREATE TABLE IF NOT EXISTS `elgg_users_apisessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_guid` bigint(20) unsigned NOT NULL,
  `site_guid` bigint(20) unsigned NOT NULL,
  `token` varchar(40) DEFAULT NULL,
  `expires` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_guid` (`user_guid`,`site_guid`),
  KEY `token` (`token`)
) ENGINE=MEMORY DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `elgg_users_apisessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `elgg_users_entity`
--

DROP TABLE IF EXISTS `elgg_users_entity`;
CREATE TABLE IF NOT EXISTS `elgg_users_entity` (
  `guid` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `username` varchar(128) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `salt` varchar(8) NOT NULL DEFAULT '',
  `email` text NOT NULL,
  `language` varchar(6) NOT NULL DEFAULT '',
  `code` varchar(32) NOT NULL DEFAULT '',
  `banned` enum('yes','no') NOT NULL DEFAULT 'no',
  `admin` enum('yes','no') NOT NULL DEFAULT 'no',
  `last_action` int(11) NOT NULL DEFAULT '0',
  `prev_last_action` int(11) NOT NULL DEFAULT '0',
  `last_login` int(11) NOT NULL DEFAULT '0',
  `prev_last_login` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`),
  UNIQUE KEY `username` (`username`),
  KEY `password` (`password`),
  KEY `email` (`email`(50)),
  KEY `code` (`code`),
  KEY `last_action` (`last_action`),
  KEY `last_login` (`last_login`),
  KEY `admin` (`admin`),
  FULLTEXT KEY `name` (`name`),
  FULLTEXT KEY `name_2` (`name`,`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `elgg_users_entity`
--

INSERT INTO `elgg_users_entity` (`guid`, `name`, `username`, `password`, `salt`, `email`, `language`, `code`, `banned`, `admin`, `last_action`, `prev_last_action`, `last_login`, `prev_last_login`) VALUES
(35, 'andres', 'andres', 'aed14caffcd58a36799db6758db137f2', 'a3aeb0c1', 'aromanowski@unq.edu.ar', 'en', '', 'no', 'yes', 1323876974, 1323876974, 1323876871, 1323870566),
(41, 'El Colo', 'El_Colo', '3f62989b62abdc387b486263d61d73fe', '847b99f2', 'pablo.rieser@gmail.com', '', '', 'no', 'yes', 0, 0, 0, 0),
(46, 'AleMerlo', 'AleMerlo', '1b6fca5b88a93f993d1cf4aa2b4db6d7', 'c9af65b7', 'merloalejandro@gmail.com', '', '', 'no', 'no', 1323869176, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `elgg_users_sessions`
--

DROP TABLE IF EXISTS `elgg_users_sessions`;
CREATE TABLE IF NOT EXISTS `elgg_users_sessions` (
  `session` varchar(255) NOT NULL,
  `ts` int(11) unsigned NOT NULL DEFAULT '0',
  `data` mediumblob,
  PRIMARY KEY (`session`),
  KEY `ts` (`ts`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `elgg_users_sessions`
--

INSERT INTO `elgg_users_sessions` (`session`, `ts`, `data`) VALUES
('1m7ts0s24tesrkt29ehuiv2ch6', 1323867725, 0x5f5f656c67675f73657373696f6e7c733a33323a223965393861373933366431323662306266623934643562316135346230363364223b6d73677c613a303a7b7d737469636b795f666f726d737c613a303a7b7d),
('hvbrbgmce4galhi5skk563dan1', 1323869776, 0x5f5f656c67675f73657373696f6e7c733a33323a223965393861373933366431323662306266623934643562316135346230363364223b6d73677c613a303a7b7d737469636b795f666f726d737c613a303a7b7d757365727c4f3a383a22456c676755736572223a383a7b733a31353a22002a0075726c5f6f76657272696465223b4e3b733a31363a22002a0069636f6e5f6f76657272696465223b4e3b733a31363a22002a0074656d705f6d65746164617461223b613a303a7b7d733a31393a22002a0074656d705f616e6e6f746174696f6e73223b613a303a7b7d733a32343a22002a0074656d705f707269766174655f73657474696e6773223b613a303a7b7d733a31313a22002a00766f6c6174696c65223b613a303a7b7d733a31333a22002a0061747472696275746573223b613a32353a7b733a31323a2274696d655f63726561746564223b733a31303a2231333233383636373937223b733a343a2267756964223b733a323a223335223b733a343a2274797065223b733a343a2275736572223b733a373a2273756274797065223b733a313a2230223b733a31303a226f776e65725f67756964223b733a313a2230223b733a31343a22636f6e7461696e65725f67756964223b733a313a2230223b733a393a22736974655f67756964223b733a313a2231223b733a393a226163636573735f6964223b733a313a2232223b733a31323a2274696d655f75706461746564223b733a31303a2231333233383639303830223b733a31313a226c6173745f616374696f6e223b733a31303a2231333233383639373736223b733a373a22656e61626c6564223b733a333a22796573223b733a31323a227461626c65735f73706c6974223b693a323b733a31333a227461626c65735f6c6f61646564223b693a323b733a343a226e616d65223b733a363a22616e64726573223b733a383a22757365726e616d65223b733a363a22616e64726573223b733a383a2270617373776f7264223b733a33323a226165643134636166666364353861333637393964623637353864623133376632223b733a343a2273616c74223b733a383a226133616562306331223b733a353a22656d61696c223b733a32323a2261726f6d616e6f77736b6940756e712e6564752e6172223b733a383a226c616e6775616765223b733a323a22656e223b733a343a22636f6465223b733a303a22223b733a363a2262616e6e6564223b733a323a226e6f223b733a353a2261646d696e223b733a333a22796573223b733a31363a22707265765f6c6173745f616374696f6e223b733a31303a2231333233383639373736223b733a31303a226c6173745f6c6f67696e223b733a31303a2231333233383637373335223b733a31353a22707265765f6c6173745f6c6f67696e223b733a31303a2231333233383636373937223b7d733a383a22002a0076616c6964223b623a303b7d677569647c733a323a223335223b69647c733a323a223335223b757365726e616d657c733a363a22616e64726573223b6e616d657c733a363a22616e64726573223b),
('9kpmj3ad7uvrckb4rrmbqqqu85', 1323869697, 0x5f5f656c67675f73657373696f6e7c733a33323a226664333263386366386533366462323366383136643664316264346466623262223b6d73677c613a303a7b7d),
('n5qu207i22ohjsgbs7gf2aemd4', 1323870557, 0x5f5f656c67675f73657373696f6e7c733a33323a226437323134353638343132343232623239626363616132393533326262306539223b6d73677c613a303a7b7d),
('u3c245k2i17elop2tu1c2sd390', 1323875814, 0x5f5f656c67675f73657373696f6e7c733a33323a223361323037366235623132643033356535363064383837383761323336636162223b),
('cm7isptt7qsm9i8m4u9up6kse5', 1323877906, 0x5f5f656c67675f73657373696f6e7c733a33323a223065636630616331626261383461623665643264373164646230663364303732223b6d73677c613a303a7b7d),
('mkso99ikimclae3nhmouempjd0', 1323871463, 0x5f5f656c67675f73657373696f6e7c733a33323a223364396661316531373462653631663930396364386431386238366134363934223b6d73677c613a303a7b7d),
('sqcustnhopgs3pco0ihjslgld1', 1323873293, 0x5f5f656c67675f73657373696f6e7c733a33323a226632333364656363376131656430396330383735313037383339393330643431223b6d73677c613a303a7b7d),
('nlm207tqah9so1ij24iuvu97u2', 1323874099, 0x5f5f656c67675f73657373696f6e7c733a33323a223937313330336534626362386636336230386562383834356233343532363836223b6d73677c613a303a7b7d),
('nifcqbia8l901muir56j4b5im2', 1323874096, 0x5f5f656c67675f73657373696f6e7c733a33323a226438353963383533356433383238376265663966383263643030633032663066223b),
('idodfprlpfefdv1bt4jgeg57o3', 1323874099, 0x5f5f656c67675f73657373696f6e7c733a33323a226166373732363762393461323930626236313362383634326566346362336565223b),
('ambjo0t2r7abs93qhmn6pdtcs0', 1323875646, 0x5f5f656c67675f73657373696f6e7c733a33323a223039626632653131383663616231353138396630363831326164376438346136223b6d73677c613a303a7b7d),
('5f153092de978cotthr40lue07', 1323876846, 0x5f5f656c67675f73657373696f6e7c733a33323a223239623461656236386366643962613931376533333834653635663631323064223b6d73677c613a303a7b7d),
('jinbr29bbnv94620155joi50i7', 1323875813, 0x5f5f656c67675f73657373696f6e7c733a33323a223137333364666138326632623965393863383038616665313836306533353436223b),
('cjteeruu0c2ir5nbneo08jv984', 1323870595, 0x5f5f656c67675f73657373696f6e7c733a33323a226361653362613761306464396131386661643665633533316139343736316661223b6d73677c613a303a7b7d),
('js4rskqjek19qt5ruj3jggtko7', 1323875815, 0x5f5f656c67675f73657373696f6e7c733a33323a226264323766646634663866616266353037326263653330313439326535376235223b),
('8oqlg99qnknuo72rkn6rs18co1', 1323875816, 0x5f5f656c67675f73657373696f6e7c733a33323a226139376364393766333363643635323665396238383739306666646531313762223b),
('jjvs4ehgotbqt9eou0pk97jlc4', 1323875817, 0x5f5f656c67675f73657373696f6e7c733a33323a223931313833653662643034373130646661343862653566653164313537346364223b),
('lneoun89hnqhaqr2tb1tum9qa3', 1323875845, 0x5f5f656c67675f73657373696f6e7c733a33323a226536653339313461383631623833323136666162643532303166333138616534223b6d73677c613a303a7b7d),
('t52lrake0rukb9jsou73n4i5g4', 1323875961, 0x5f5f656c67675f73657373696f6e7c733a33323a226335653931653566333334366330633866353034316235376461633730636463223b),
('rkg507fe7o5q6tnujevhijlpt6', 1323876000, 0x5f5f656c67675f73657373696f6e7c733a33323a223737636630653966363632656239613237343231356632653663303439636164223b),
('7274s15rl63kjpoqk207p419g0', 1323876202, 0x5f5f656c67675f73657373696f6e7c733a33323a223661313039343130363964623566666630336336313838336361613439656133223b),
('r6csh27ceoj1p9bps6t95ipf25', 1323876203, 0x5f5f656c67675f73657373696f6e7c733a33323a226566396533393738646365356134626465343634343833636635383363346538223b),
('vbn2pf5qvpjbtc5lkd09vm1nc0', 1323876204, 0x5f5f656c67675f73657373696f6e7c733a33323a223538336661353862663734353730383439623165373636303634306235316136223b),
('7bvb4sb8l0k68jssv24qbfgrq2', 1323876205, 0x5f5f656c67675f73657373696f6e7c733a33323a226164333238643162653364323037636164383236613531313663623064623038223b),
('ltcupa96vont5gbaoc16vjt2f1', 1323876208, 0x5f5f656c67675f73657373696f6e7c733a33323a223735643536343832366636363732663263646236303536383364653931306437223b),
('oeq8iqbp3ce8fkqinajp8gs1r0', 1323876209, 0x5f5f656c67675f73657373696f6e7c733a33323a226430323561613164623039653834643235373665376439626365316434376433223b),
('tcngkkcduoaa235el4na761ac7', 1323876214, 0x5f5f656c67675f73657373696f6e7c733a33323a223233653333306537363830356630313930306565613133333061653564633164223b),
('9dovdvlinl7dcgphr8k53gc196', 1323876514, 0x5f5f656c67675f73657373696f6e7c733a33323a226433336334333631346366643735663762656235373364643863663865363162223b6d73677c613a313a7b733a353a226572726f72223b613a313a7b693a303b733a33383a22466f726d206973206d697373696e67205f5f746f6b656e206f72205f5f7473206669656c6473223b7d7d),
('ov7a3nm38lbcbrd57i1pcmm8g7', 1323876622, 0x5f5f656c67675f73657373696f6e7c733a33323a226235333731383632336563313430646635613436326233643364316639316233223b),
('dsgqugi0telfed0n8ub04ic6t5', 1323876633, 0x5f5f656c67675f73657373696f6e7c733a33323a226662623263646636353661343164383663333432656464383064363830366234223b),
('ij5d6qpj92rest6un0aavc0fv7', 1323876645, 0x5f5f656c67675f73657373696f6e7c733a33323a226234616330353234396433396266356564356233333535333238303431316538223b),
('os10uikv07pqi9qukcagf2iq83', 1323876654, 0x5f5f656c67675f73657373696f6e7c733a33323a223464353364656163626235646338323137636632653166346164316136333639223b),
('3ksrc0v33180gg8tpd0p996ou5', 1323876684, 0x5f5f656c67675f73657373696f6e7c733a33323a223932653163646339376536643062383765393430393535366264306364626536223b),
('me3h8o2fpde3co732ob53v0o72', 1323876713, 0x5f5f656c67675f73657373696f6e7c733a33323a226264373261656662633662396236343965633464636165653362393766643530223b),
('8jhgumisp2tqps0d1apd4cvs41', 1323876765, 0x5f5f656c67675f73657373696f6e7c733a33323a226637626536396436373365643639323336346263623165313264366136396331223b),
('krf8gpbh7t4hrb8k2omata3a94', 1323876783, 0x5f5f656c67675f73657373696f6e7c733a33323a226265396563363863633766326334633531373835633436316136373463346466223b),
('770qeu4pqr2ve1l424fs41cnv6', 1323876802, 0x5f5f656c67675f73657373696f6e7c733a33323a223066646432643139303834326333636262376233383038353837633965356636223b),
('3a3nukblm1qeqs79ueei3506t1', 1323876817, 0x5f5f656c67675f73657373696f6e7c733a33323a223636366238663033336438333733643364386339636534356537356565396363223b),
('4462rnv5ngrqdtddm0br3lq9s7', 1323876831, 0x5f5f656c67675f73657373696f6e7c733a33323a223661326265303465333136376164316434623962346161363763663163663433223b),
('bjujhpmo7ts9n0a54s9lk0n815', 1323876832, 0x5f5f656c67675f73657373696f6e7c733a33323a226662373762353566306562333662646166323638376564646363316563663836223b),
('rpreola8b7nvhkqnb5cura86e4', 1323876846, 0x5f5f656c67675f73657373696f6e7c733a33323a226562613861666661613564346235626333623765373033323362353662323163223b),
('14ajkaopn3dcbo9rdilkkcd457', 1323876974, 0x5f5f656c67675f73657373696f6e7c733a33323a223239623461656236386366643962613931376533333834653635663631323064223b6d73677c613a303a7b7d757365727c4f3a383a22456c676755736572223a383a7b733a31353a22002a0075726c5f6f76657272696465223b4e3b733a31363a22002a0069636f6e5f6f76657272696465223b4e3b733a31363a22002a0074656d705f6d65746164617461223b613a303a7b7d733a31393a22002a0074656d705f616e6e6f746174696f6e73223b613a303a7b7d733a32343a22002a0074656d705f707269766174655f73657474696e6773223b613a303a7b7d733a31313a22002a00766f6c6174696c65223b613a303a7b7d733a31333a22002a0061747472696275746573223b613a32353a7b733a31323a2274696d655f63726561746564223b733a31303a2231333233383636373937223b733a343a2267756964223b733a323a223335223b733a343a2274797065223b733a343a2275736572223b733a373a2273756274797065223b733a313a2230223b733a31303a226f776e65725f67756964223b733a313a2230223b733a31343a22636f6e7461696e65725f67756964223b733a313a2230223b733a393a22736974655f67756964223b733a313a2231223b733a393a226163636573735f6964223b733a313a2232223b733a31323a2274696d655f75706461746564223b733a31303a2231333233383736383731223b733a31313a226c6173745f616374696f6e223b733a31303a2231333233383736393734223b733a373a22656e61626c6564223b733a333a22796573223b733a31323a227461626c65735f73706c6974223b693a323b733a31333a227461626c65735f6c6f61646564223b693a323b733a343a226e616d65223b733a363a22616e64726573223b733a383a22757365726e616d65223b733a363a22616e64726573223b733a383a2270617373776f7264223b733a33323a226165643134636166666364353861333637393964623637353864623133376632223b733a343a2273616c74223b733a383a226133616562306331223b733a353a22656d61696c223b733a32323a2261726f6d616e6f77736b6940756e712e6564752e6172223b733a383a226c616e6775616765223b733a323a22656e223b733a343a22636f6465223b733a303a22223b733a363a2262616e6e6564223b733a323a226e6f223b733a353a2261646d696e223b733a333a22796573223b733a31363a22707265765f6c6173745f616374696f6e223b733a31303a2231333233383736393733223b733a31303a226c6173745f6c6f67696e223b733a31303a2231333233383736383731223b733a31353a22707265765f6c6173745f6c6f67696e223b733a31303a2231333233383730353636223b7d733a383a22002a0076616c6964223b623a303b7d677569647c733a323a223335223b69647c733a323a223335223b757365726e616d657c733a363a22616e64726573223b6e616d657c733a363a22616e64726573223b),
('maoeie76n9bghif531986rk717', 1323876871, 0x5f5f656c67675f73657373696f6e7c733a33323a223062376361383262346237306463316338393661346466306430306637386439223b),
('lrb3ts5t9uekkkk8pqa3qkum71', 1323876876, 0x5f5f656c67675f73657373696f6e7c733a33323a223864326662346161336335356134666464373530396232623264656330636630223b),
('d936qhab6g5ii6fgl8bbjphb23', 1323876908, 0x5f5f656c67675f73657373696f6e7c733a33323a226434623134323562613363616263356139616135663939323264663032643035223b),
('f9kpnskrkjesq3qketcn199u72', 1323877906, 0x5f5f656c67675f73657373696f6e7c733a33323a223938376166383664633338646336353134323631353864623432623635343863223b),
('l6cjhbhdj8im98p91bqjme3l44', 1323878206, 0x5f5f656c67675f73657373696f6e7c733a33323a223364613631383035383135323037396535613537373936393736643237623331223b6d73677c613a313a7b733a353a226572726f72223b613a313a7b693a303b733a33383a22466f726d206973206d697373696e67205f5f746f6b656e206f72205f5f7473206669656c6473223b7d7d),
('fo2s9ttllnt3fd3fua3f2ced93', 1323878506, 0x5f5f656c67675f73657373696f6e7c733a33323a226466353031343935613238653730636365393665613431366537373565633861223b6d73677c613a313a7b733a353a226572726f72223b613a313a7b693a303b733a33383a22466f726d206973206d697373696e67205f5f746f6b656e206f72205f5f7473206669656c6473223b7d7d),
('ft0niecc3alodq2k9in8ngmoo6', 1323878806, 0x5f5f656c67675f73657373696f6e7c733a33323a223166386532646133376365643537306536663138653665373861326334333336223b6d73677c613a313a7b733a353a226572726f72223b613a313a7b693a303b733a33383a22466f726d206973206d697373696e67205f5f746f6b656e206f72205f5f7473206669656c6473223b7d7d),
('hlntlujaq2vkj1ok3p5ve56252', 1323879106, 0x5f5f656c67675f73657373696f6e7c733a33323a226266336561613739396135343163353634303233326435333530643766633764223b6d73677c613a313a7b733a353a226572726f72223b613a313a7b693a303b733a33383a22466f726d206973206d697373696e67205f5f746f6b656e206f72205f5f7473206669656c6473223b7d7d);
